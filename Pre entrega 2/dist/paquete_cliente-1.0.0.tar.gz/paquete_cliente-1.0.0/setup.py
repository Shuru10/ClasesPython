from setuptools import setup

setup(
    author="Joaquin Del Aguila",
    author_email="Joacodelaguila@gmail.com",
    description="Entrega de creacion de paquete redistribuible",
    version="1.0.0",
    name="Paquete_Cliente",
    packages=["paquete"]
)

  